#!/data/data/com.ivarna.fluxlinux/files/usr/bin/sh

echo "$@"
