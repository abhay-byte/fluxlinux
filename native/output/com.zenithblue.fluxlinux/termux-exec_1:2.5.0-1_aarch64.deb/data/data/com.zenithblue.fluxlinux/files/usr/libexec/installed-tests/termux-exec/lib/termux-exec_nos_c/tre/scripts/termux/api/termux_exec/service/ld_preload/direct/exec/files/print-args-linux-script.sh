#!/data/data/com.zenithblue.fluxlinux/files/usr/bin/sh

echo "$@"
